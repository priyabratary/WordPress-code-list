<?php get_template_part('includes/header');

/*
Template Name: SEO

*/

 ?>

<!-- /.container -->

<section>
     <!-- start banner -->
         	<?php get_template_part('includes/inner-banner-seo'); ?>
         <!-- end banner -->
         
             <!--start-gry-wraper-->
                <div  class="gry-wraper p-t-60 p-b-120" name="myAnchor" id="myAnchor">
                
                
                            
                            	<!--end-->
                                
                                 <?php get_template_part('includes/loops/content', 'page-why'); ?>
                                <!--end-->
                                
                      

                </div>
             <!--end-gry-wraper-->
             
            
         
     </section>

<?php get_template_part('includes/footer'); ?>
